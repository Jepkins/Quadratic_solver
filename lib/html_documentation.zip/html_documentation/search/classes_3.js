var searchData=
[
  ['solution_0',['Solution',['../struct_solution.html',1,'']]]
];
