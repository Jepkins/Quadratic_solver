var searchData=
[
  ['clear_5fbuffer_0',['clear_buffer',['../input__output_8h.html#af6a694960df5fae7d26d369493209b99',1,'input_output.h']]],
  ['coefficients_1',['Coefficients',['../struct_coefficients.html',1,'']]]
];
