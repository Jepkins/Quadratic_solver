var searchData=
[
  ['coefficients_0',['Coefficients',['../struct_coefficients.html',1,'']]]
];
