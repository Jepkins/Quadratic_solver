var searchData=
[
  ['input_5fcoefficients_0',['Input_Coefficients',['../_quadratic__solver_8cpp.html#a1e6a49a4ba02f1cfc200cd8dac0a0cf1',1,'Quadratic_solver.cpp']]],
  ['is_5fzero_1',['Is_Zero',['../double__arithmetics_8h.html#a8e80e3a12ed393f7347fa0252822e5a4',1,'double_arithmetics.h']]]
];
