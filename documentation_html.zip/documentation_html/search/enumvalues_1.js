var searchData=
[
  ['no_5fsolutions_0',['NO_SOLUTIONS',['../flagging_8h.html#abc1c2b0cecbb1e016d8fd31bb855575fa7ba2733ae0b3f049b4fcd4afedd9b980',1,'flagging.h']]]
];
