var searchData=
[
  ['one_5fsolution_0',['ONE_SOLUTION',['../flagging_8h.html#abc1c2b0cecbb1e016d8fd31bb855575fa0451cd6d5aa789cdc383e452dd2c0bd7',1,'flagging.h']]],
  ['output_5froots_1',['Output_Roots',['../_quadratic__solver_8cpp.html#a6a3613cd899cb5b9ad0071e905ff57da',1,'Quadratic_solver.cpp']]]
];
