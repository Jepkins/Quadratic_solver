var searchData=
[
  ['double_5fdeviation_0',['DOUBLE_DEVIATION',['../double__arithmetics_8h.html#aaa779d1edb3e57bad369a705a9141552',1,'double_arithmetics.h']]]
];
