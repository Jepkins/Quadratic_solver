var searchData=
[
  ['clear_5fbuffer_0',['Clear_Buffer',['../_quadratic__solver_8cpp.html#a7960e4d8424220a20169402041f9d211',1,'Quadratic_solver.cpp']]]
];
