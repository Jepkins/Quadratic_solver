var searchData=
[
  ['n_5fof_5fsolutions_0',['N_OF_SOLUTIONS',['../flagging_8h.html#abc1c2b0cecbb1e016d8fd31bb855575f',1,'flagging.h']]],
  ['no_5fsolutions_1',['NO_SOLUTIONS',['../flagging_8h.html#abc1c2b0cecbb1e016d8fd31bb855575fa7ba2733ae0b3f049b4fcd4afedd9b980',1,'flagging.h']]]
];
