var searchData=
[
  ['undefined_0',['UNDEFINED',['../flagging_8h.html#abc1c2b0cecbb1e016d8fd31bb855575fa605159e8a4c32319fd69b5d151369d93',1,'flagging.h']]]
];
