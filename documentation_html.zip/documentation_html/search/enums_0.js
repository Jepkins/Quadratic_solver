var searchData=
[
  ['n_5fof_5fsolutions_0',['N_OF_SOLUTIONS',['../flagging_8h.html#abc1c2b0cecbb1e016d8fd31bb855575f',1,'flagging.h']]]
];
