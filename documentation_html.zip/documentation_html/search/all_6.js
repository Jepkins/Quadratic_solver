var searchData=
[
  ['main_0',['main',['../_quadratic__solver_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;Quadratic_solver.cpp'],['../_tester_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;Tester.cpp']]],
  ['max_1',['max',['../double__arithmetics_8h.html#a452d2724d2f82cc2c17f54b388232200',1,'double_arithmetics.h']]],
  ['min_2',['min',['../double__arithmetics_8h.html#a82fe34140a419a1f19200091b808e4ad',1,'double_arithmetics.h']]]
];
