var searchData=
[
  ['quad_5fdefine_5fand_5fsolve_0',['Quad_Define_and_Solve',['../define__equation__and__solve_8h.html#a8eb1af62983e9e26c517c2ccba2b62fe',1,'define_equation_and_solve.h']]],
  ['quadratic_5fsolver_2ecpp_1',['Quadratic_solver.cpp',['../_quadratic__solver_8cpp.html',1,'']]]
];
