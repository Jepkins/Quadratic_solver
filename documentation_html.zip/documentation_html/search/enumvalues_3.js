var searchData=
[
  ['two_5fsolutions_0',['TWO_SOLUTIONS',['../flagging_8h.html#abc1c2b0cecbb1e016d8fd31bb855575fa7b4b3bca57d544a80aaed928315a1c75',1,'flagging.h']]]
];
