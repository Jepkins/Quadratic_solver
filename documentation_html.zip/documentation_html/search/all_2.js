var searchData=
[
  ['define_5fequation_5fand_5fsolve_2eh_0',['define_equation_and_solve.h',['../define__equation__and__solve_8h.html',1,'']]],
  ['double_5farithmetics_2eh_1',['double_arithmetics.h',['../double__arithmetics_8h.html',1,'']]],
  ['double_5fdeviation_2',['DOUBLE_DEVIATION',['../double__arithmetics_8h.html#aaa779d1edb3e57bad369a705a9141552',1,'double_arithmetics.h']]]
];
