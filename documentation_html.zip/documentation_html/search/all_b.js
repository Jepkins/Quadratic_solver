var searchData=
[
  ['solve_5fconstant_0',['Solve_Constant',['../define__equation__and__solve_8h.html#a4b1bfef201cad3b691b8be7c4b62863b',1,'define_equation_and_solve.h']]],
  ['solve_5ffull_5fquad_1',['Solve_Full_Quad',['../define__equation__and__solve_8h.html#a803f6d6e78a4692f2d0c684792b5bccc',1,'define_equation_and_solve.h']]],
  ['solve_5flinear_2',['Solve_Linear',['../define__equation__and__solve_8h.html#a958561a820550f7cf17d592603028029',1,'define_equation_and_solve.h']]]
];
